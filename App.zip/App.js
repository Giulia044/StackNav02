import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Principal from './src/Telas/Principal';
import Pizza from './src/Telas/Pizza';
import Sushi from './src/Telas/Sushi';
import Hamburguer from './src/Telas/Hamburguer';

const Stack = createNativeStackNavigator();

export default function App() {

  return (

    <NavigationContainer>

      <Stack.Navigator>

        <Stack.Screen
          name="Principal"
          component={Principal}
          options={{
            headerStyle: {
              backgroundColor: '#000',
            },
            headerTintColor: '#fff',
            title: 'Bem Vindo(a)'
          }}
        />

        <Stack.Screen
          name="Pizza"
          component={Pizza}
          options={{
            headerStyle: {
              backgroundColor: '#d62828',
            },
            headerTintColor: '#fff',
          }}
        />

        <Stack.Screen
          name="Sushi"
          component={Sushi}
          options={{
            headerStyle: {
              backgroundColor: '#1d4ed8',
            },
            headerTintColor: '#fff',
          }}
        />

        <Stack.Screen
          name="Hamburguer"
          component={Hamburguer}
          options={{
            headerStyle: {
              backgroundColor: '#f4b400',
            },
            headerTintColor: '#000',
          }}
        />

      </Stack.Navigator>

    </NavigationContainer>

  );
}